﻿Release Notes

Dell EMC OpenManage Plug-in Version 3.0 for Nagios Core

-------------------------------------------------------------------------------
Dell EMC OpenManage Plug-in version 3.0 for Nagios Core provides capabilities 
for Out-of-Band (Agent-Free) management of 12th and later generations of 
PowerEdge Servers, Modular Infrastructure, Hyper-Converged Infrastructure (HCI), 
Datacenter Scalable Solutions(DSS), Storage and Networking devices. This plug-in 
provides complete hardware-level visibility including detailed inventory, health 
status (both overall and component-level health status) and SNMP trap monitoring 
for supported devices. Dell EMC PowerEdge Servers, DSS and HCI are monitored 
using a combination of Redfish based RESTful APIs, WS-Man APIs and/or SNMP 
protocol provided by iDRAC with Lifecycle Controller. In addition, out-of-band 
monitoring of Dell EMC Modular Infrastructure is supported using the WS-Man APIs 
and SNMP protocol provided by Chassis Management Controller (CMC), whereas 
Dell EMC Storage and Networking devices are monitored using the SNMP protocol 
only. One-to-One web console launch of the respective element managers for 
iDRAC, Modular Infrastructure, Storage and Network devices is also supported by 
the OpenManage Plug-in to perform further troubleshooting, configuration and 
management activities.

*******************************************************************************

Version: 3.0 

*******************************************************************************

Release Date: April 2018

*******************************************************************************

Previous Versions: 1.0, 2.0 and 2.1

*******************************************************************************

Importance
----------
OPTIONAL: Dell EMC recommends the customer to review specifics about the 
software update to determine if it applies to your system. The update contains 
changes that impact certain configurations, or provides new features that 
may/may not apply to your environment. 

*******************************************************************************

Platform(s) Affected 
--------------------

For the list of supported platforms, see the section "Support Matrix" in the 
"Dell EMC OpenManage Plug-in Version 3.0 for Nagios Core User's Guide" at 
dell.com/openmanagemanuals.

*******************************************************************************

What is Supported?
------------------
Dell EMC OpenManage Plug-in Version 3.0 for Nagios Core is supported on Nagios 
Core version 3.5.0 and later.

For the list of supported software, operating systems and other requirements, 
see the "Dell EMC OpenManage Plug-in Version 3.0 for Nagios Core Installation 
Guide" at dell.com/openmanagemanuals.

*******************************************************************************
What’s New?
-----------

* Simplified plugin installation and deployment with Enhanced host and service 
  checks

* Support Redfish REST APIs for monitoring PowerEdge Servers and HCI platforms

* Support for Dell EMC Network Switches

* Support for OEM Servers 

* Upgrade from previous Dell OpenManage Plug-in Version 2.0 and Dell EMC 
  OpenManage Plug-in Version 2.1 to the current Dell EMC OpenManage Plug-in 
  Version 3.0 for Nagios Core.
  
*******************************************************************************

Fixes
-----

NA
  
*******************************************************************************

Important Notes 
---------------
To visit Dell TechCenter for accessing whitepapers, blogs, wiki-articles, 
videos, Product communities and forums, see:  
http://en.community.dell.com/techcenter/systems-management/w/wiki/
6277.dell-openmanage-plug-in-for-nagios-core

*******************************************************************************

Known Issues
------------
* Issue 1(25122):
  Description: In "Dell EMC Chassis I/O Module Status" service, value for 
  "FabricType" is shown incorrectly as "UNKNOWN, for few IO Modules when Dell 
  PowerEdge M1000e chassis is discovered.
  
  Version Affected: Dell EMC OpenManage Plug-in Version 3.0 for Nagios XI.
   
* Issue 2(25121): 
  Description: In "Dell EMC Chassis power supply status" service, health status 
  for one of the power supply instance which is standby is shown as "UNKNOWN"  
  when Dell EMC Chassis is discovered.
  
  Version Affected: Dell EMC OpenManage Plug-in Version 3.0 for Nagios XI.
  
  Resolution: Launch the respective chassis console for the Dell PowerEdge 
  M1000e, Dell PowerEdge VRTX, and Dell PowerEdge FX2/FX2s chassis host from 
  the Nagios XI to view the the health status of standby power supply. 

* Issue 3(178686):
  Description: SNMP traps are not received from the Dell EMC device in the 
  Nagios Core console for Ubuntu setup. 
  
  Version Affected: Dell EMC OpenManage Plug-in Version 3.0 for Nagios Core.  
   
* Issue 4(255091):
  Description: In "Dell EMC Server Overall Health Status" service, Power Supply 
  Status is shown as OK instead of UNKNOWN when DSS 1510 device is discovered 
  using SNMP and WSMan protocol.

  Version Affected: Dell EMC OpenManage Plug-in Version 3.0 for Nagios Core.
  
* Issue 5(92913):
  Description: "Dell EMC Network Switch Physical Port Status" service may get 
  timed out in case high number of vlan/virtual ports are configured under 
  monitored Dell EMC Network device.
 
  Version Affected: Dell EMC OpenManage Plug-in Version 3.0 for Nagios Core.  
  
  Resolution: Launch the respective switch console for the Dell EMC Network 
  Switch host from the Nagios Core to view the the health status of physical 
  port.
 
* Issue 6(93599): 
  Description: In "Dell EMC Server Controller Status" service, an extra instance 
  will be shown only when Dell EMC PowerEdge server is been discovered using 
  RedFish protocol and that device have SATA controller.
  
  Version Affected: Dell EMC OpenManage Plug-in Version 3.0 for Nagios Core.
  
  Resolution: Launch the respective device console for the Dell EMC PowerEdge 
  Server from Nagios Core to view the actual controller instance.
  
* Issue 7(98517):
  Description: Discovery of Dell EMC PowerEdge 14G server (Rack and Cloud) 
  with firmware versions between 3.00.00.00 and 3.15.15.15 using IPv6 with 
  WSMan or RedFish protocol will fail.
  
  Version Affected: Dell EMC OpenManage Plug-in Version 3.0 for Nagios Core.
  
*******************************************************************************

Limitations
-----------

* IPv6 traps are not associated with the corresponding Dell EMC device in the 
  Nagios Core console.

*******************************************************************************

Installation Prerequisites
--------------------------
For the installation prerequisites, see the "Dell EMC OpenManage Plug-in Version 
3.0 for Nagios Core Installation Guide" at dell.com/openmanagemanuals 

*******************************************************************************

Installation Procedure
----------------------
For installation or update related information, see the "Dell EMC OpenManage 
Plug-in Version 3.0 for Nagios Core Installation Guide" at 
dell.com/openmanagemanuals 

*******************************************************************************

Installation and Configuration Notes
------------------------------------
For installation and configuration related information, see the "Dell EMC 
OpenManage Plug-in Version 3.0 for Nagios Core Installation Guide" at 
dell.com/openmanagemanuals

*******************************************************************************

Contacting Dell
---------------

Note: If you do not have an active Internet connection, you can find contact 
information on your purchase invoice, packing slip, bill, or Dell product 
catalog.

Dell provides several online and telephone-based support and service options. 
Availability varies by country and product, and some services may not be 
available in your area. To contact Dell for sales, technical support, or 
customer service issues:
1. Go to Dell.com/support.
2. Select your support category. 
3. Verify your country or region in the Choose a Country/Region drop-down list 
    at the bottom of the page.
4. Select the appropriate service or support link based on your need.              

-------------------------------------------------------------------------------
Information in this document is subject to change without notice.

Copyright © 2018 Dell Inc. or its subsidiaries. All rights reserved. Dell, EMC, 
and other trademarks are trademarks of Dell Inc. or its subsidiaries. Other 
trademarks may be trademarks of their respective owners.

