How to enable ssh on ESXi:
==========================
1) Run Vsphere client
2) choose ip/hostname of ESXi in left list
3) choose Configuration tab
4) choose Security Profile
5) choose SSH and options...
6) Click start

How to enable snmp on  ESXi:
============================

Version 5.1 and 5.5:
--------------------
1) ssh login as root
2) run command
   esxcli system snmp set -c public22
3) run command
   esxcli system snmp set -e yes

Version 5.0:
------------
1) ssh login as root
2) edit file /etc/vmware/snmp.xml (you need know vi editor)
   vi /etc/vmware/snmp.xml
   change:
     <enabled>false</enabled> to <enabled>true</enabled>
     <communities></communities> to <communities>public</communities>
3) run command
   /sbin/services.sh restart


How to install template:
========================
1) import xml template cacti_host_template_esxi_5_x.xml
   Cacti -> Console -> Import Templates
2) copy file scripts/ss_esxi_vhosts.php to your_cacti_instalation/scripts/
3) copy files resource/snmp_queries to your_cacti_instalation/resource/snmp_queries/


How to use template:
====================
Add host and choose Host template ESXi
You can graph:
- vhosts - number of hosts, running, installed vm client tools
- Logged in Users and number of processes
- Processor load for every CPU core (strange works on 5.0, better on 5.1, fine on 5.5)
- HW - state of Logical volumes, FANs, ...
     - does not make sense graphs hw with state unknown (only running(2), warninkg(3)) and make threshold
- Get Mounted partitions - on 5.1 and higher last grap will be Real Memory
- Interface statistics - NICs


Version:
========
0.2 - Fix ss_esxi_vhosts.php - Running vhosts = 0 on ESXi 5.0
0.1 